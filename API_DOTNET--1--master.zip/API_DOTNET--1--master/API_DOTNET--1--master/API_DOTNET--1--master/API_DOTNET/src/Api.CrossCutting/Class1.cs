﻿namespace Api.CrossCutting;

public class Class1
{

}
