using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Api.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Api.Data.Mapping
{
    public class BooksMap : IEntityTypeConfiguration<UserEntity>
    {
        public void Configure(EntityTypeBuilder<UserEntity> builder)
        {
            builder.ToTable("Books");

            builder.HasKey(u => u.Id);

            builder.HasIndex(u => u.Titulo)
                .IsUnique();

            builder.Property(u => u.Titulo)
                .IsRequired()
                .HasMaxLength(100);

            builder.Property(u => u.Genero)
                .HasMaxLength(50);

            builder.Property(u => u.Editora)
                .HasMaxLength(100);

            

        }
    }
}