using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Api.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Api.Data.Mapping
{
    public class UserMap : IEntityTypeConfiguration<UserEntity>
    {
        public void Configure(EntityTypeBuilder<UserEntity> builder)
        {
            builder.ToTable("User");

            builder.HasKey(u => u.Id);

            builder.HasIndex(u => u.Email)
                .IsUnique();

            builder.Property(u => u.Email)
                .HasMaxLength(100);

            builder.Property(u => u.Nome)
                .IsRequired()
                .HasMaxLength(60);

            builder.Property(u => u.Titulo)
                .HasMaxLength(100);
            
            builder.Property(u => u.Genero)
                .HasMaxLength(50);

            builder.Property(u => u.Editora)
                .HasMaxLength(100);
            
            builder.Property(u => u.EnderecoCliente)
                .HasMaxLength(100);

            builder.Property(u => u.TelefoneCliente)
                .HasMaxLength(20);
            
            builder.Property(u => u.PrecoLivro)
                .HasMaxLength(7);

            builder.Property(u => u.MetodoPagamento)
                .HasMaxLength(30);
            
            builder.Property(u => u.EntregaDomicilio)
                .HasMaxLength(10);

        }
    }
}