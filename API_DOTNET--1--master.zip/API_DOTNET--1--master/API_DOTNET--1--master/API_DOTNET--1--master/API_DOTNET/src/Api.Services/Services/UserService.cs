using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Api.Domain.Entities;
using Api.Domain.Interfaces;
using Api.Domain.Interfaces.Services.User;

namespace Api.Services.Services
{
    public class UserService : IUserService
    {
        private IRepository<UserEntity> _repository;
        private IRepository<BooksEntity> _repository2;
        public UserService(IRepository<UserEntity> repository)
        {
            _repository = repository;
        }

        
        public async Task<bool> Delete(Guid id)
        {
            return await _repository.DeleteAsync(id);
        }

        public async Task<UserEntity> Get(Guid id)
        {
            return await _repository.SelectAsync(id);
        }

        public async Task<UserEntity> GetBooks(Guid id)
        {
            return await _repository.GetBooksAsync(id);
        }

        

        public async Task<UserEntity> GetTitulo(UserEntity Titulo)
        {
            return await _repository.GetTituloAsync(Titulo);
        }

        public async Task<UserEntity> GetEditora(UserEntity Editora)
        {
            return await _repository.GetEditoraAsync(Editora);
        }

        public async Task<UserEntity> GetGenero(UserEntity Genero)
        {
            return await _repository.GetGeneroAsync(Genero);
        }

        public async Task<UserEntity> GetEntregaDomicilio(UserEntity EntregaDomicilio)
        {
            return await _repository.GetEntregaDomicilioAsync(EntregaDomicilio);
        }
        public async Task<UserEntity> GetMetodoPagamento(UserEntity MetodoPagamento)
        {
            return await _repository.GetMetodoPagamentoAsync(MetodoPagamento);
        }

        public async Task<UserEntity> GetPrecoLivro(UserEntity PrecoLivro)
        {
            return await _repository.GetPrecoLivroAsync(PrecoLivro);
        }
        public async Task<IEnumerable<UserEntity>> GetAllBooks()
        {
            return await _repository.GetAllBooksAsync();
        }

        public async Task<UserEntity> PostBooks(UserEntity books)
        {
            return await _repository.InsertBooksAsync(books);
        }
        public async Task<UserEntity> PutBooks(UserEntity books)
        {
            return await _repository.UpdateBooksAsync(books);
        }
        

        public async Task<IEnumerable<UserEntity>> GetAll()
        {
            return await _repository.SelectAsync();
        }

        

        public async Task<UserEntity> Post(UserEntity user)
        {
            return await _repository.InsertAsync(user);
        }

        

        public async Task<UserEntity> Put(UserEntity user)
        {
            return await _repository.UpdateAsync(user);
        }
    }
}