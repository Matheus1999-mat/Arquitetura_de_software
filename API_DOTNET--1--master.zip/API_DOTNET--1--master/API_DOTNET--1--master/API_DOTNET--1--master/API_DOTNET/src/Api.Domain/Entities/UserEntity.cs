using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Domain.Entities
{
    public class UserEntity : BaseEntity
    {
        public string  Nome { get; set; }
        public string Email { get; set; }

        public string  Titulo { get; set; }
        public string Genero { get; set; }
        public string Editora { get; set; }
        public DateTime DataCompra = DateTime.Now;
        public string EnderecoCliente{get;set;}
        public string TelefoneCliente{get;set;}
        public string MetodoPagamento{get;set;}
        public string EntregaDomicilio{get;set;}
        public string PrecoLivro{get;set;}
    }
}