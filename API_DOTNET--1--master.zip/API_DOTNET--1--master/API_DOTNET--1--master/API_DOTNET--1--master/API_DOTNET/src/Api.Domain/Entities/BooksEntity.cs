using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Domain.Entities
{
    public class BooksEntity : BaseEntity
    {
        public string  Titulo { get; set; }
        public string Genero { get; set; }
        public string Editora { get; set; }
    }
}