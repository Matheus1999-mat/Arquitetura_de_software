using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Api.Domain.Entities;

namespace Api.Domain.Interfaces.Services.User
{
    public interface IUserService
    {
        Task<UserEntity> Get (Guid id);
        Task<UserEntity> GetBooks (Guid id);
        Task<UserEntity> GetTitulo (UserEntity Titulo);
        Task<UserEntity> GetEditora (UserEntity Editora);
        Task<UserEntity> GetGenero (UserEntity Genero);
        Task<UserEntity> GetMetodoPagamento (UserEntity MetodoPagamento);
        Task<UserEntity> GetEntregaDomicilio (UserEntity EntregaDomicilio);
        Task<UserEntity> GetPrecoLivro (UserEntity PrecoLivro);
        Task<IEnumerable<UserEntity>> GetAllBooks ();
        Task<UserEntity> PostBooks (UserEntity user);
        Task<UserEntity> PutBooks (UserEntity user);
        Task<bool> DeleteBooks (Guid id);

        Task<IEnumerable<UserEntity>> GetAll ();
        Task<UserEntity> Post (UserEntity user);
        Task<UserEntity> Put (UserEntity user);
        Task<bool> Delete (Guid id);

    }
}