using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Api.Domain.Entities;

namespace Api.Domain.Interfaces
{
    public interface IRepository<T> where T : BaseEntity
    {
        Task<T> InsertAsync (T item);
        Task<T> InsertBooksAsync (T item);
        Task<T> UpdateAsync (T item);
        Task<T> UpdateBooksAsync (T item);
        Task<T> GetTituloAsync (UserEntity Titulo);
        Task<T> GetEditoraAsync (UserEntity Editora);
        Task<T> GetGeneroAsync (UserEntity Genero);
        Task<T> GetEntregaDomicilioAsync (UserEntity EntregaDomicilio);
        Task<T> GetPrecoLivroAsync (UserEntity PrecoLivro);
        Task<T> GetMetodoPagamentoAsync (UserEntity MetodoPagamento);
        

        Task<IEnumerable<T>> GetAllBooksAsync ();
        Task<bool> DeleteAsync (Guid id);
        Task<T> SelectAsync (Guid id);
        Task<T> GetBooksAsync (Guid id);
        Task<IEnumerable<T>> SelectAsync ();
        Task<bool> ExistAsync(Guid id);
    }
}