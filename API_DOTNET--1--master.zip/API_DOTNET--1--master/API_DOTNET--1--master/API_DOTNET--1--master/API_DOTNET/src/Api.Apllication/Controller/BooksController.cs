
using System.Net;
using Api.Domain.Entities;
using Api.Domain.Interfaces.Services.User;
using Microsoft.AspNetCore.Mvc;

namespace Api.Apllication.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private IUserService _service;

        public BooksController(IUserService service)
        {
            _service = service;
        }
        [HttpGet]
        public async Task<ActionResult> GetAllBooks ()
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState); //404
            }
            try
            {
                return Ok(await _service.GetAllBooks());
            }
            catch (ArgumentException e)
            {
                
                return StatusCode((int) HttpStatusCode.InternalServerError, e.Message);
            }
        }

        // [HttpGet]
        // [Route("{id}", Name = "GetBooksWithId")]

        // public async Task<ActionResult> GetBooks(Guid id)
        // {
        //     if(!ModelState.IsValid)
        //     {
        //         return BadRequest(ModelState); //404
        //     }
        //     try
        //     {
        //         return Ok(await _service.GetBooks(id));
        //     }
        //     catch (ArgumentException e)
        //     {
                
        //         return StatusCode((int) HttpStatusCode.InternalServerError, e.Message);
        //     }
        // }
        [HttpPost("Titulo")]
        // [HttpPost]
        // [Route("{Titulo}", Name = "GetWithTitulo")]

        public async Task<ActionResult> GetTitulo([FromBody] UserEntity Titulo)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState); //404
            }
            try
            {
                return Ok(await _service.GetTitulo(Titulo));
            }
            catch (ArgumentException e)
            {
                
                return StatusCode((int) HttpStatusCode.InternalServerError, e.Message);
            }
        }
        [HttpPost("Editora")]
        // [HttpPost]
        // [Route("{Editora}", Name = "GetWithEditora")]

        public async Task<ActionResult> GetEditora([FromBody] UserEntity Editora)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState); //404
            }
            try
            {
                return Ok(await _service.GetEditora(Editora));
            }
            catch (ArgumentException e)
            {
                
                return StatusCode((int) HttpStatusCode.InternalServerError, e.Message);
            }
        }
        [HttpPost("Genero")]
        // [HttpPost]
        // [Route("{Genero}", Name = "GetWithGenero")]

        public async Task<ActionResult> GetGenero([FromBody] UserEntity Genero)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState); //404
            }
            try
            {
                return Ok(await _service.GetGenero(Genero));
            }
            catch (ArgumentException e)
            {
                
                return StatusCode((int) HttpStatusCode.InternalServerError, e.Message);
            }
        }
        [HttpPost("PrecoLivro")]
        // [HttpPost]
        // [Route("{PrecoLivro}", Name = "GetWithPrecoLivro")]

        public async Task<ActionResult> GetPrecoLivro([FromBody] UserEntity PrecoLivro)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState); //404
            }
            try
            {
                return Ok(await _service.GetPrecoLivro(PrecoLivro));
            }
            catch (ArgumentException e)
            {
                
                return StatusCode((int) HttpStatusCode.InternalServerError, e.Message);
            }
        }
        [HttpPost("EntregaDomicilio")]
        // [HttpPost]
        // [Route("{EntregaDomicilio}", Name = "GetWithEntregaDomicilio")]

        public async Task<ActionResult> GetEntregaDomicilio([FromBody] UserEntity EntregaDomicilio)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState); //404
            }
            try
            {
                return Ok(await _service.GetEntregaDomicilio(EntregaDomicilio));
            }
            catch (ArgumentException e)
            {
                
                return StatusCode((int) HttpStatusCode.InternalServerError, e.Message);
            }
        }
        [HttpPost("MetodoPagamento")]
        // [HttpPost]
        // [Route("{MetodoPagamento}", Name = "GetWithMetodoPagamento")]

        public async Task<ActionResult> GetMetodoPagamento([FromBody] UserEntity MetodoPagamento)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState); //404
            }
            try
            {
                return Ok(await _service.GetMetodoPagamento(MetodoPagamento));
            }
            catch (ArgumentException e)
            {
                
                return StatusCode((int) HttpStatusCode.InternalServerError, e.Message);
            }
        }

        [HttpDelete("{id}")]
        
        public async Task<ActionResult> Delete(Guid id)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState); //404
            }
            try
            {
                return Ok(await _service.Delete(id));
            }
            catch (ArgumentException e)
            {
                
                return StatusCode((int) HttpStatusCode.InternalServerError, e.Message);
            }
        }
        [HttpPost]
        public async Task<ActionResult> PostBooks ([FromServices] IUserService _service, [FromBody] UserEntity books)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var result = await _service.PostBooks(books);
                if (result != null)
                {
                    return Created(new Uri(Url.Link("GetWithId", new {id = result.Id})), result);
                } else
                {
                    return BadRequest();
                }
            }
            catch (ArgumentException e)
            {
                
                return StatusCode((int)HttpStatusCode.InternalServerError, e.Message);
            }
        }
        [HttpPut]
        public async Task<ActionResult> PutBooks([FromServices] IUserService _service, [FromBody] UserEntity books)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var result = await _service.PutBooks(books);
                if (result != null)
                {
                    return Ok(result);
                }
                else
                {
                    return BadRequest();
                }
            }
            catch (ArgumentException e)
            {

                return StatusCode((int)HttpStatusCode.InternalServerError, e.Message);
            }
        }


    }
}